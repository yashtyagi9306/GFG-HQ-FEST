# myapp/urls.py
from django.urls import path
from .views import vehicle_footprint_view

urlpatterns = [
    path('vehicle-footprint/', vehicle_footprint_view, name='submit_vehicle_footprint'),
]
