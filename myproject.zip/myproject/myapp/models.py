# myapp/models.py
from djongo import models

class VehicleFootprint(models.Model):
    car_miles = models.IntegerField()
    car_efficiency = models.FloatField()
    public_transport_miles = models.IntegerField(null=True, blank=True)
    public_transport_efficiency = models.FloatField(null=True, blank=True)

    class Meta:
        db_table = 'vehicle_footprint'  # MongoDB collection name
