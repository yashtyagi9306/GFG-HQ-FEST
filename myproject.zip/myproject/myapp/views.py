# myapp/views.py
from django.shortcuts import render
from django.http import HttpResponse
from .models import VehicleFootprint
from django.shortcuts import redirect


def vehicle_footprint_view(request):
    if request.method == 'POST':
        car_miles = float(request.POST.get('car_miles'))
        car_efficiency = float(request.POST.get('car_efficiency'))
        public_transport_miles = float(request.POST.get('public_transport_miles'))
        public_transport_efficiency = float(request.POST.get('public_transport_efficiency'))

        # Create a new VehicleFootprint instance and save it to MongoDB
        footprint = VehicleFootprint(
            car_miles=car_miles,
            car_efficiency=car_efficiency,
            public_transport_miles=public_transport_miles,
            public_transport_efficiency=public_transport_efficiency
        )
        footprint.save()
        re_content="""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Carbon Footprint Calculator</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            background-color: #f0f0f0;
        }
        .container {
            max-width: 800px;
            margin: 0 auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h1 {
            text-align: center;
        }
        label {
            font-weight: bold;
        }
        input[type="text"], select {
            width: 100%;
            padding: 10px;
            margin: 5px 0 15px;
            border-radius: 5px;
            border: 1px solid #ccc;
        }
        input[type="submit"] {
            width: 100%;
            padding: 15pxpx;
            background-color: #28a745;
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 18px;
        }
        input[type="submit"]:hover {
            background-color: #218838;
        }
    </style>
</head>
<body>
            <div class="container">
        <h1>Your Carbon footprint is Here</h1>
        <p> Carbon footprint for your is as follows::<br>For Petrol car : """+str((car_miles/car_efficiency)*2.31)+"""kg<br></p>
        <p>For Diesel Car: """+str((car_miles/car_efficiency)*2.68)+"""kg</p>
</div>
</body>
</html>"""


        return HttpResponse(re_content)

    return render(request, 'myapp/form.html')
